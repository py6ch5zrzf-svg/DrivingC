# DrivingC — GitHub / TestFlight

## Важно

GitHub хранит исходный код проекта. Сам по себе GitHub не устанавливает приложение на iPhone.

Самый удобный постоянный вариант для iPhone — **TestFlight**:
GitHub → сборка проекта → TestFlight → установка на iPhone.

Для установки на настоящий iPhone нужна подпись Apple. Её нельзя безопасно встроить в исходники проекта.

## Что уже подготовлено

- DrivingC.xcodeproj
- Assets.xcassets и иконка
- Bundle ID: `com.georgiy.drivingc`
- GitHub Actions workflow для проверки сборки проекта на macOS
- README и `.gitignore`
- полностью офлайн-хранение данных приложения

## Если есть Mac с Xcode

1. Загрузить содержимое этого проекта в репозиторий GitHub `DrivingC`.
2. На Mac клонировать репозиторий.
3. Открыть `DrivingC.xcodeproj`.
4. В Xcode выбрать свой Apple Account / Team.
5. Проверить Signing & Capabilities.
6. Подключить iPhone и запустить приложение.
7. Для удобной установки без кабеля опубликовать сборку через TestFlight.

## Если Mac нет

Одного iPhone + GitHub недостаточно для первоначальной подписанной сборки iOS-приложения.
Я могу отдельно подготовить проект под **Xcode Cloud + TestFlight**, чтобы после первичной настройки сборки максимально автоматизировать обновления из GitHub.

## GitHub Actions

Файл `.github/workflows/ios-build.yml` автоматически проверяет, что проект собирается на macOS runner.
Эта проверка не создаёт подписанный IPA для установки на личный iPhone — для этого требуется Apple signing.
