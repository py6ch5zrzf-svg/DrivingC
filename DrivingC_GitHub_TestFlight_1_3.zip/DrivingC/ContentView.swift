import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Главная", systemImage: "house") }

            StudentsView()
                .tabItem { Label("Ученики", systemImage: "person.2") }

            CalendarView()
                .tabItem { Label("Календарь", systemImage: "calendar") }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var store: DrivingStore
    @State private var showBooking = false

    var todayLessons: [Lesson] {
        store.lessons
            .filter { Calendar.current.isDateInToday($0.date) }
            .sorted { $0.date < $1.date }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        showBooking = true
                    } label: {
                        Label("Записать на вождение", systemImage: "plus.circle.fill")
                    }
                }

                Section("Сегодня") {
                    if todayLessons.isEmpty {
                        Text("На сегодня занятий нет")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(todayLessons) { lesson in
                            LessonRow(lesson: lesson)
                        }
                    }
                }

                Section("Всего") {
                    LabeledContent("Ученики", value: "\(store.students.count)")
                    LabeledContent("Занятий", value: "\(store.lessons.count)")
                }
            }
            .navigationTitle("Вождение — C")
            .sheet(isPresented: $showBooking) {
                LessonEditorView()
            }
        }
    }
}

struct StudentsView: View {
    @EnvironmentObject private var store: DrivingStore
    @State private var search = ""
    @State private var showAdd = false

    var filtered: [Student] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return store.students }
        return store.students.filter {
            $0.name.localizedCaseInsensitiveContains(q) ||
            $0.phone.localizedCaseInsensitiveContains(q)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(filtered) { student in
                    NavigationLink {
                        StudentDetailView(student: student)
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(student.name)
                            if !student.phone.isEmpty {
                                Text(student.phone)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                .onDelete { offsets in
                    offsets.map { filtered[$0] }.forEach(store.deleteStudent)
                }
            }
            .searchable(text: $search, prompt: "Поиск ученика")
            .navigationTitle("Ученики")
            .toolbar {
                Button {
                    showAdd = true
                } label: {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showAdd) {
                StudentEditorView()
            }
        }
    }
}

struct StudentDetailView: View {
    @EnvironmentObject private var store: DrivingStore
    let student: Student
    @State private var editing = false
    @State private var showBooking = false

    private var currentStudent: Student {
        store.student(for: student.id) ?? student
    }

    var body: some View {
        List {
            Section("Данные") {
                if !currentStudent.phone.isEmpty {
                    LabeledContent("Телефон", value: currentStudent.phone)
                }
                if !currentStudent.notes.isEmpty {
                    Text(currentStudent.notes)
                }
                LabeledContent("Занятий", value: "\(store.lessons(for: student.id).count)")
                LabeledContent("Часов", value: String(format: "%.1f", Double(store.totalMinutes(for: student.id)) / 60.0))
            }

            Section("Занятия") {
                let items = store.lessons(for: student.id)
                if items.isEmpty {
                    Text("Занятий пока нет")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(items) { lesson in
                        LessonRow(lesson: lesson)
                            .contentShape(Rectangle())
                            .onTapGesture { }
                    }
                    .onDelete { offsets in
                        offsets.map { items[$0] }.forEach(store.deleteLesson)
                    }
                }
            }
        }
        .navigationTitle(currentStudent.name)
        .toolbar {
            ToolbarItemGroup {
                Button {
                    showBooking = true
                } label: {
                    Image(systemName: "plus")
                }
                Button {
                    editing = true
                } label: {
                    Image(systemName: "pencil")
                }
            }
        }
        .sheet(isPresented: $editing) {
            StudentEditorView(student: currentStudent)
        }
        .sheet(isPresented: $showBooking) {
            LessonEditorView(preselectedStudentID: currentStudent.id)
        }
    }
}

struct LessonRow: View {
    @EnvironmentObject private var store: DrivingStore
    let lesson: Lesson
    @State private var editing = false

    var body: some View {
        Button {
            editing = true
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(lesson.date, style: .time)
                        .font(.headline)
                    Text(store.student(for: lesson.studentID)?.name ?? "Ученик")
                    Text("\(lesson.duration) мин")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $editing) {
            LessonEditorView(lesson: lesson)
        }
    }
}

struct StudentEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: DrivingStore

    let student: Student?
    @State private var name: String
    @State private var phone: String
    @State private var notes: String

    init(student: Student? = nil) {
        self.student = student
        _name = State(initialValue: student?.name ?? "")
        _phone = State(initialValue: student?.phone ?? "")
        _notes = State(initialValue: student?.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                TextField("Имя и фамилия", text: $name)
                TextField("Телефон", text: $phone)
                    .keyboardType(.phonePad)
                TextField("Примечания", text: $notes, axis: .vertical)
            }
            .navigationTitle(student == nil ? "Новый ученик" : "Изменить ученика")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        if let student {
                            store.updateStudent(Student(id: student.id, name: name, phone: phone, notes: notes))
                        } else {
                            store.addStudent(name: name, phone: phone, notes: notes)
                        }
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

struct LessonEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: DrivingStore

    let lesson: Lesson?
    let preselectedStudentID: UUID?

    @State private var studentID: UUID?
    @State private var date: Date
    @State private var duration: Int
    @State private var notes: String
    @State private var reminder: Int
    @State private var errorMessage: String?
    @State private var showDeleteConfirm = false

    init(lesson: Lesson? = nil, preselectedStudentID: UUID? = nil) {
        self.lesson = lesson
        self.preselectedStudentID = preselectedStudentID
        _studentID = State(initialValue: lesson?.studentID ?? preselectedStudentID)
        _date = State(initialValue: lesson?.date ?? Date())
        _duration = State(initialValue: lesson?.duration ?? 60)
        _notes = State(initialValue: lesson?.notes ?? "")
        _reminder = State(initialValue: lesson?.reminderMinutes ?? 30)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ученик") {
                    if store.students.isEmpty {
                        Text("Сначала добавьте ученика во вкладке «Ученики».")
                            .foregroundStyle(.secondary)
                    } else {
                        Picker("Ученик", selection: $studentID) {
                            Text("Выберите").tag(UUID?.none)
                            ForEach(store.students) { student in
                                Text(student.name).tag(Optional(student.id))
                            }
                        }
                    }
                }

                Section("Время") {
                    DatePicker("Дата и время", selection: $date)
                    Picker("Длительность", selection: $duration) {
                        Text("60 мин").tag(60)
                        Text("90 мин").tag(90)
                        Text("120 мин").tag(120)
                    }
                }

                Section("Напоминание") {
                    Picker("Напомнить", selection: $reminder) {
                        Text("Без напоминания").tag(0)
                        Text("За 30 минут").tag(30)
                        Text("За 1 час").tag(60)
                        Text("За 2 часа").tag(120)
                        Text("За 1 день").tag(1440)
                    }
                }

                Section("Примечание") {
                    TextField("Например: город / площадка", text: $notes, axis: .vertical)
                }

                if let errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                    }
                }

                if lesson != nil {
                    Section {
                        Button("Удалить занятие", role: .destructive) {
                            showDeleteConfirm = true
                        }
                    }
                }
            }
            .navigationTitle(lesson == nil ? "Новое занятие" : "Изменить занятие")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") { save() }
                        .disabled(studentID == nil || store.students.isEmpty)
                }
            }
            .confirmationDialog("Удалить это занятие?", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) {
                    if let lesson { store.deleteLesson(lesson) }
                    dismiss()
                }
                Button("Отмена", role: .cancel) {}
            }
            .onAppear {
                store.requestNotifications()
            }
        }
    }

    private func save() {
        guard let studentID else { return }
        let newLesson = Lesson(
            id: lesson?.id ?? UUID(),
            studentID: studentID,
            date: date,
            duration: duration,
            notes: notes,
            reminderMinutes: reminder
        )

        do {
            if lesson == nil {
                try store.addLesson(newLesson)
            } else {
                try store.updateLesson(newLesson)
            }
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct CalendarView: View {
    @EnvironmentObject private var store: DrivingStore
    @State private var mode = 0
    @State private var selectedDate = Date()
    @State private var monthDate = Date()
    @State private var showBooking = false

    private let modes = ["День", "Неделя", "Месяц"]

    var body: some View {
        NavigationStack {
            VStack {
                Picker("Период", selection: $mode) {
                    ForEach(0..<modes.count, id: \.self) { i in
                        Text(modes[i]).tag(i)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)

                if mode == 0 {
                    DayCalendar(selectedDate: $selectedDate)
                } else if mode == 1 {
                    WeekCalendar(selectedDate: $selectedDate)
                } else {
                    MonthCalendar(monthDate: $monthDate, selectedDate: $selectedDate)
                }

                Divider()

                let lessons = lessonsForDisplay()
                if lessons.isEmpty {
                    ContentUnavailableView("Нет занятий", systemImage: "calendar.badge.exclamationmark",
                                           description: Text("На выбранный период занятий нет."))
                } else {
                    List(lessons) { lesson in
                        LessonRow(lesson: lesson)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Календарь")
            .toolbar {
                Button {
                    showBooking = true
                } label: {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showBooking) {
                LessonEditorView()
            }
        }
    }

    private func lessonsForDisplay() -> [Lesson] {
        let cal = Calendar.current
        switch mode {
        case 0:
            return store.lessons.filter { cal.isDate($0.date, inSameDayAs: selectedDate) }.sorted { $0.date < $1.date }
        case 1:
            guard let interval = cal.dateInterval(of: .weekOfYear, for: selectedDate) else { return [] }
            return store.lessons.filter { interval.contains($0.date) }.sorted { $0.date < $1.date }
        default:
            guard let interval = cal.dateInterval(of: .month, for: monthDate) else { return [] }
            return store.lessons.filter { interval.contains($0.date) }.sorted { $0.date < $1.date }
        }
    }
}

struct DayCalendar: View {
    @Binding var selectedDate: Date
    var body: some View {
        DatePicker("Дата", selection: $selectedDate, displayedComponents: [.date])
            .datePickerStyle(.graphical)
            .padding(.horizontal)
    }
}

struct WeekCalendar: View {
    @EnvironmentObject private var store: DrivingStore
    @Binding var selectedDate: Date

    var weekDays: [Date] {
        guard let interval = Calendar.current.dateInterval(of: .weekOfYear, for: selectedDate) else { return [] }
        return (0..<7).compactMap {
            Calendar.current.date(byAdding: .day, value: $0, to: interval.start)
        }
    }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack {
                ForEach(weekDays, id: \.self) { day in
                    let count = store.lessons.filter { Calendar.current.isDate($0.date, inSameDayAs: day) }.count
                    Button {
                        selectedDate = day
                    } label: {
                        VStack(spacing: 5) {
                            Text(day, format: .dateTime.weekday(.abbreviated))
                            Text(day, format: .dateTime.day())
                                .font(.title3.bold())
                            if count > 0 {
                                Text("\(count)")
                                    .font(.caption2)
                            } else {
                                Text(" ")
                                    .font(.caption2)
                            }
                        }
                        .frame(width: 52, height: 72)
                    }
                    .buttonStyle(.bordered)
                }
            }
            .padding()
        }
    }
}

struct MonthCalendar: View {
    @EnvironmentObject private var store: DrivingStore
    @Binding var monthDate: Date
    @Binding var selectedDate: Date

    private let columns = Array(repeating: GridItem(.flexible()), count: 7)

    var days: [Date] {
        let cal = Calendar.current
        guard let interval = cal.dateInterval(of: .month, for: monthDate) else { return [] }
        let firstWeekday = cal.component(.weekday, from: interval.start)
        let leading = (firstWeekday - cal.firstWeekday + 7) % 7
        let count = cal.range(of: .day, in: .month, for: monthDate)?.count ?? 0

        var result: [Date] = Array(repeating: interval.start, count: leading)
        for day in 0..<count {
            if let date = cal.date(byAdding: .day, value: day, to: interval.start) {
                result.append(date)
            }
        }
        return result
    }

    var body: some View {
        VStack {
            HStack {
                Button { shiftMonth(-1) } label: { Image(systemName: "chevron.left") }
                Spacer()
                Text(monthDate, format: .dateTime.month(.wide).year())
                    .font(.headline)
                Spacer()
                Button { shiftMonth(1) } label: { Image(systemName: "chevron.right") }
            }
            .padding(.horizontal)

            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(["Пн","Вт","Ср","Чт","Пт","Сб","Вс"], id: \.self) {
                    Text($0).font(.caption).foregroundStyle(.secondary)
                }

                ForEach(Array(days.enumerated()), id: \.offset) { _, day in
                    let count = store.lessons.filter { Calendar.current.isDate($0.date, inSameDayAs: day) }.count
                    Button {
                        selectedDate = day
                    } label: {
                        VStack(spacing: 2) {
                            Text(day, format: .dateTime.day())
                            Text(count > 0 ? "•" : " ")
                                .font(.caption)
                        }
                        .frame(maxWidth: .infinity, minHeight: 38)
                        .background(Calendar.current.isDate(day, inSameDayAs: selectedDate) ? Color.primary.opacity(0.12) : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal)
        }
        .onChange(of: selectedDate) { _, newValue in
            if Calendar.current.isDate(newValue, equalTo: monthDate, toGranularity: .month) == false {
                monthDate = newValue
            }
        }
    }

    private func shiftMonth(_ value: Int) {
        if let date = Calendar.current.date(byAdding: .month, value: value, to: monthDate) {
            monthDate = date
            selectedDate = date
        }
    }
}
