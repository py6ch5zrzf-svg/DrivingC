import SwiftUI

@main
struct DrivingCApp: App {
    @StateObject private var store = DrivingStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environment(\.locale, Locale(identifier: "ru_RU"))
        }
    }
}
