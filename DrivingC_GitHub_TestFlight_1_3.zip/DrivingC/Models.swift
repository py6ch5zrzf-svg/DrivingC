import Foundation

struct Student: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var phone: String = ""
    var notes: String = ""
}

struct Lesson: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var studentID: UUID
    var date: Date
    var duration: Int
    var notes: String = ""
    var reminderMinutes: Int = 30
}
