import Foundation
import UserNotifications

@MainActor
final class DrivingStore: ObservableObject {
    @Published var students: [Student] = [] { didSet { save() } }
    @Published var lessons: [Lesson] = [] { didSet { save() } }

    private let studentsKey = "DrivingC.students"
    private let lessonsKey = "DrivingC.lessons"

    init() {
        load()
    }

    func student(for id: UUID) -> Student? {
        students.first { $0.id == id }
    }

    func lessons(for studentID: UUID) -> [Lesson] {
        lessons.filter { $0.studentID == studentID }.sorted { $0.date < $1.date }
    }

    func totalMinutes(for studentID: UUID) -> Int {
        lessons(for: studentID).reduce(0) { $0 + $1.duration }
    }

    func addStudent(name: String, phone: String, notes: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        students.append(Student(name: trimmed, phone: phone, notes: notes))
    }

    func updateStudent(_ student: Student) {
        guard let index = students.firstIndex(where: { $0.id == student.id }) else { return }
        students[index] = student
    }

    func deleteStudent(_ student: Student) {
        lessons(for: student.id).forEach { cancelNotification(for: $0) }
        students.removeAll { $0.id == student.id }
        lessons.removeAll { $0.studentID == student.id }
    }

    enum BookingError: LocalizedError {
        case overlap
        var errorDescription: String? {
            "На это время уже назначено другое занятие."
        }
    }

    func hasOverlap(_ candidate: Lesson) -> Bool {
        let start = candidate.date
        let end = candidate.date.addingTimeInterval(TimeInterval(candidate.duration * 60))

        return lessons.contains { existing in
            guard existing.id != candidate.id else { return false }
            let existingEnd = existing.date.addingTimeInterval(TimeInterval(existing.duration * 60))
            return start < existingEnd && end > existing.date
        }
    }

    func addLesson(_ lesson: Lesson) throws {
        if hasOverlap(lesson) { throw BookingError.overlap }
        lessons.append(lesson)
        scheduleNotification(for: lesson)
    }

    func updateLesson(_ lesson: Lesson) throws {
        if hasOverlap(lesson) { throw BookingError.overlap }
        cancelNotification(for: lesson)
        guard let index = lessons.firstIndex(where: { $0.id == lesson.id }) else { return }
        lessons[index] = lesson
        scheduleNotification(for: lesson)
    }

    func deleteLesson(_ lesson: Lesson) {
        cancelNotification(for: lesson)
        lessons.removeAll { $0.id == lesson.id }
    }

    func scheduleNotification(for lesson: Lesson) {
        guard lesson.reminderMinutes > 0 else { return }
        guard lesson.date > Date() else { return }

        let content = UNMutableNotificationContent()
        let studentName = student(for: lesson.studentID)?.name ?? "Ученик"
        content.title = "Вождение"
        content.body = "\(studentName) — занятие по вождению"
        content.sound = .default

        let triggerDate = lesson.date.addingTimeInterval(TimeInterval(-lesson.reminderMinutes * 60))
        guard triggerDate > Date() else { return }

        let components = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute],
            from: triggerDate
        )
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(
            identifier: lesson.id.uuidString,
            content: content,
            trigger: trigger
        )

        UNUserNotificationCenter.current().add(request)
    }

    func cancelNotification(for lesson: Lesson) {
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: [lesson.id.uuidString])
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    private func save() {
        let encoder = JSONEncoder()
        if let data = try? encoder.encode(students) {
            UserDefaults.standard.set(data, forKey: studentsKey)
        }
        if let data = try? encoder.encode(lessons) {
            UserDefaults.standard.set(data, forKey: lessonsKey)
        }
    }

    private func load() {
        let decoder = JSONDecoder()
        if let data = UserDefaults.standard.data(forKey: studentsKey),
           let value = try? decoder.decode([Student].self, from: data) {
            students = value
        }
        if let data = UserDefaults.standard.data(forKey: lessonsKey),
           let value = try? decoder.decode([Lesson].self, from: data) {
            lessons = value
        }
    }
}
